<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->integer('project_request_id');
            $table->integer('promoter_id');
            $table->string('name');
            $table->string('website')->nullable();
            $table->longText('short_detail');
            $table->json('purpose');
            $table->string('start_month');
            $table->string('start_year');
            $table->string('degree');
            $table->string('mission');
            $table->longText('investors');
            $table->longText('cause');
            $table->longText('biography');
            $table->longText('detail');
            $table->integer('status')->default(0);
            $table->longText('admin_message')->nullable();
            $table->string('video')->nullable();
            $table->string('slide')->nullable();
            $table->string('document')->nullable();
            $table->string('cover_image')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
};
