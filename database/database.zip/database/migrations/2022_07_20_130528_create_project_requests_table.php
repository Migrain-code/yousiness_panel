<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_requests', function (Blueprint $table) {
            $table->id();
            $table->integer('promoter_id');
            $table->string('name');
            $table->string('website')->nullable();
            $table->longText('short_detail');
            $table->json('purpose');
            $table->string('start_month');
            $table->string('start_year');
            $table->string('degree');
            $table->string('mission');
            $table->longText('cause');
            $table->longText('biography');
            $table->longText('detail');
            $table->integer('status')->default(0);
            $table->longText('admin_message')->nullable();
            $table->string('video')->nullable();
            $table->string('slide')->nullable();
            $table->string('document')->nullable();
            $table->integer('is_published')->nullable();
            $table->integer('project_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_requests');
    }
};
