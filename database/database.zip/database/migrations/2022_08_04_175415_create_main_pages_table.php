<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('main_pages', function (Blueprint $table) {
            $table->id();
            $table->string('bannerTitle');
            $table->string('bannerSubtitle');
            $table->json('bannerBoxes');
            $table->string('sec1Title');
            $table->string('sec1SubTitle');
            $table->string('sec1Description');
            $table->string('sec1Image');
            $table->json('sec1Boxes');
            $table->string('sec2Title');
            $table->string('sec2SubTitle');
            $table->string('sec2Description');
            $table->string('sec2Image');
            $table->json('sec2Boxes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('main_pages');
    }
};
