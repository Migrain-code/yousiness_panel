<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('abouts', function (Blueprint $table) {
            $table->id();
            $table->string('bannerTitle');
            $table->string('bannerSubtitle');
            $table->string('bannerImage');
            $table->string('sec1Title');
            $table->string('sec1SubTitle');
            $table->json('sec1boxes');
            $table->string('sec2Title');
            $table->string('sec2description');
            $table->string('sec2Image');
            $table->json('sec2boxes');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('abouts');
    }
};
